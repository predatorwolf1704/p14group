from collections import Counter

import bcrypt


# with open("img.txt", "rb") as f:
#     d = f.read()
#
# # d = d.decode()
# with open("img.png", "wb") as f:
#     f.write(d)
#
# a = "absdfgjhkfdgsgg"
# print(a.encode('utf-8'))

# password = '1234'
# bytes = password.encode('utf-8')
# salt = bcrypt.gensalt()
# hash = bcrypt.hashpw(bytes, salt)
#
#
# new_pass = "1234"
# bytes_pass = new_pass.encode('utf-8')
# print(bcrypt.checkpw(bytes_pass, hash))



a = "aabb"
print(Counter(a))




















